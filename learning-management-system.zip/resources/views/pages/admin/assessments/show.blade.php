@extends('layouts.app')
@section('content')
<x-common.page-breadcrumb :pageTitle="$assessment->title" :translate="false">
    <x-slot:actions>
        @can('assessments.edit')<a href="{{ route(\App\Support\PortalRoute::name('assessments.edit'), $assessment) }}" class="rounded-lg border border-gray-300 px-4 py-2.5 text-sm dark:border-gray-700 dark:text-white">{{ __('Edit settings') }}</a>@endcan
        @can('assessments.publish')<form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessments.status'), $assessment) }}">@csrf @method('PATCH')<input type="hidden" name="status" value="{{ $assessment->status->value === 'published' ? 'closed' : 'published' }}"><button class="rounded-lg bg-brand-500 px-4 py-2.5 text-sm text-white">{{ __($assessment->status->value === 'published' ? 'Close quiz' : 'Publish quiz') }}</button></form>@endcan
        @can('assessments.delete')<form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessments.destroy'), $assessment) }}" onsubmit="return confirm('Delete this quiz?')">@csrf @method('DELETE')<button class="rounded-lg bg-error-50 px-4 py-2.5 text-sm text-error-600">{{ __('Delete') }}</button></form>@endcan
    </x-slot:actions>
</x-common.page-breadcrumb>
@php($questionsLocked = $assessment->status === \App\Enums\AssessmentStatus::Published || (int) ($assessment->attempts_count ?? 0) > 0)
<div class="grid gap-6 xl:grid-cols-[1fr_340px]">
    <div class="space-y-6">
        <x-common.component-card title="Questions" desc="Objective questions are graded automatically.">
            <div class="space-y-4">
                @forelse($assessment->questions as $question)
                    <article class="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
                        <div class="flex items-start justify-between gap-3">
                            <div><p class="text-xs text-gray-500">{{ __('Question') }} {{ $loop->iteration }} · {{ $question->type->label() }} · {{ $question->marks }} {{ __('marks') }}</p><h3 class="mt-1 font-medium text-gray-800 dark:text-white">{{ $question->prompt }}</h3></div>
                            @can('assessments.edit')
                                @if(! $questionsLocked)
                                    <div class="flex gap-2"><a href="{{ route(\App\Support\PortalRoute::name('assessment-questions.edit'), $question) }}" class="rounded border border-gray-300 px-2 py-1 text-xs dark:border-gray-700 dark:text-white">{{ __('Edit') }}</a><form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessment-questions.destroy'), $question) }}" onsubmit="return confirm('Delete this question?')">@csrf @method('DELETE')<button class="rounded bg-error-50 px-2 py-1 text-xs text-error-600">{{ __('Delete') }}</button></form></div>
                                @endif
                            @endcan
                        </div>
                        <ul class="mt-3 grid gap-2 sm:grid-cols-2">@foreach($question->options as $option)<li class="rounded-lg px-3 py-2 text-sm {{ $option->is_correct ? 'bg-success-50 text-success-700 dark:bg-success-500/10 dark:text-success-400' : 'bg-gray-50 text-gray-600 dark:bg-white/[0.03] dark:text-gray-300' }}">{{ $option->is_correct ? '✓' : '○' }} {{ $option->option_text }}</li>@endforeach</ul>
                    </article>
                @empty
                    <p class="py-8 text-center text-sm text-gray-500">{{ __('No questions yet.') }}</p>
                @endforelse
            </div>
        </x-common.component-card>
        @can('assessments.edit')
            @if(! $questionsLocked)
                <x-common.component-card title="Add question" desc="Use multiple choice when more than one answer is correct."><form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessment-questions.store'), $assessment) }}" class="space-y-6">@csrf @include('pages.admin.assessments._question-form', ['question' => null])<div class="text-right"><button class="rounded-lg bg-brand-500 px-4 py-2.5 text-sm text-white">{{ __('Add question') }}</button></div></form></x-common.component-card>
            @else
                <p class="rounded-xl border border-warning-200 bg-warning-50 p-4 text-sm text-warning-700">{{ __('Questions are locked after publishing or once an attempt has started.') }}</p>
            @endif
        @endcan
    </div>
    <aside class="space-y-6">
        <x-common.component-card title="Quiz rules"><dl class="space-y-3 text-sm"><div class="flex justify-between"><dt class="text-gray-500">{{ __('Status') }}</dt><dd><x-ui.badge :color="$assessment->status->value === 'published' ? 'success' : 'warning'">{{ __($assessment->status->value) }}</x-ui.badge></dd></div><div class="flex justify-between"><dt class="text-gray-500">{{ __('Questions') }}</dt><dd class="text-gray-800 dark:text-white">{{ $assessment->questions->count() }}</dd></div><div class="flex justify-between"><dt class="text-gray-500">{{ __('Total marks') }}</dt><dd class="text-gray-800 dark:text-white">{{ $assessment->questions->sum('marks') }}</dd></div><div class="flex justify-between"><dt class="text-gray-500">{{ __('Duration') }}</dt><dd class="text-gray-800 dark:text-white">{{ $assessment->duration_minutes }} {{ __('min') }}</dd></div><div class="flex justify-between"><dt class="text-gray-500">{{ __('Pass score') }}</dt><dd class="text-gray-800 dark:text-white">{{ $assessment->passing_percentage }}%</dd></div><div class="flex justify-between"><dt class="text-gray-500">{{ __('Attempts') }}</dt><dd class="text-gray-800 dark:text-white">{{ $assessment->max_attempts }}</dd></div></dl>@if($assessment->instructions)<p class="mt-4 border-t border-gray-100 pt-4 text-sm text-gray-500 dark:border-gray-800">{{ $assessment->instructions }}</p>@endif</x-common.component-card>
        @can('assessments.assign')<x-common.component-card title="Standalone assignments"><form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessment-assignments.store'), $assessment) }}" class="space-y-4">@csrf <x-form.multiselect name="trainees[]" label="Assign trainees" :options="$trainees" /><x-form.input name="due_at" label="Due date" type="datetime-local" help="Use the application timezone." /><p class="-mt-2 text-xs text-gray-500">{{ __('Timezone') }}: {{ config('app.timezone') }}</p><button class="w-full rounded-lg bg-brand-500 px-4 py-2.5 text-sm text-white">{{ __('Assign quiz') }}</button></form><div class="divide-y divide-gray-100 dark:divide-gray-800">@forelse($assessment->assignments as $assignment)<div class="flex items-center justify-between py-3 text-sm"><div><p class="text-gray-800 dark:text-white">{{ $assignment->trainee->name }}</p><p class="text-xs text-gray-500">{{ $assignment->due_at?->format('M j, Y g:i A') ?? __('No deadline') }}</p></div><form method="POST" action="{{ route(\App\Support\PortalRoute::name('assessment-assignments.destroy'), $assignment) }}">@csrf @method('DELETE')<button class="text-xs text-error-500">{{ __('Remove') }}</button></form></div>@empty<p class="pt-4 text-sm text-gray-500">{{ __('No direct assignments.') }}</p>@endforelse</div></x-common.component-card>@endcan
    </aside>
</div>
@endsection
